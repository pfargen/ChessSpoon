﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks;

namespace ChessSpoon
{
    internal class ClassUCI
    {
        private Process engineProcess;
        public void StartEngine(string enginePath)
        {
            engineProcess = new Process();
            engineProcess.StartInfo.FileName = enginePath;
            engineProcess.StartInfo.RedirectStandardInput = true;
            engineProcess.StartInfo.RedirectStandardOutput = true;
            engineProcess.StartInfo.RedirectStandardError = true;
            engineProcess.StartInfo.UseShellExecute = false;
            engineProcess.StartInfo.CreateNoWindow = true;
            //engineProcess.OutputDataReceived += (sender, args) => Console.WriteLine(args.Data);
            engineProcess.OutputDataReceived += (sender, args) => ReadEngineMessage(args.Data);
            engineProcess.Start();
            engineProcess.BeginOutputReadLine();
        }

        public void SendCommand(string command)
        {            
            engineProcess.StandardInput.WriteLine(command);
            engineProcess.StandardInput.Flush();            
        }

        public void StopEngine()
        {
            SendCommand("quit");
            engineProcess.WaitForExit();
            engineProcess.Close();
        }
        private void ReadEngineMessage(string sEngineMessage )
        {            
            Console.WriteLine(sEngineMessage);            
        }
    }
}
