﻿namespace ChessSpoon
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnStartProcess = new Button();
            btnSendCommand = new Button();
            btnQuit = new Button();
            tbCommand = new TextBox();
            btnSendTextbox = new Button();
            lbCommands = new ListBox();
            toolTip1 = new ToolTip(components);
            label3 = new Label();
            tbPathToEngine = new TextBox();
            openFileDialog1 = new OpenFileDialog();
            SuspendLayout();
            // 
            // btnStartProcess
            // 
            btnStartProcess.Location = new Point(46, 96);
            btnStartProcess.Name = "btnStartProcess";
            btnStartProcess.Size = new Size(75, 40);
            btnStartProcess.TabIndex = 0;
            btnStartProcess.Text = "Start UCI Engine";
            btnStartProcess.UseVisualStyleBackColor = true;
            btnStartProcess.Click += BtnStartProcess_Click;
            // 
            // btnSendCommand
            // 
            btnSendCommand.Enabled = false;
            btnSendCommand.Location = new Point(46, 142);
            btnSendCommand.Name = "btnSendCommand";
            btnSendCommand.Size = new Size(86, 40);
            btnSendCommand.TabIndex = 1;
            btnSendCommand.Text = "Send UCI + isready";
            btnSendCommand.UseVisualStyleBackColor = true;
            btnSendCommand.Click += BtnSendCommand_Click;
            // 
            // btnQuit
            // 
            btnQuit.Enabled = false;
            btnQuit.Location = new Point(46, 320);
            btnQuit.Name = "btnQuit";
            btnQuit.Size = new Size(75, 40);
            btnQuit.TabIndex = 4;
            btnQuit.Text = "Quit";
            btnQuit.UseVisualStyleBackColor = true;
            btnQuit.Click += BtnQuit_Click;
            // 
            // tbCommand
            // 
            tbCommand.Location = new Point(46, 205);
            tbCommand.Name = "tbCommand";
            tbCommand.Size = new Size(476, 23);
            tbCommand.TabIndex = 2;
            tbCommand.Text = "ucinewgame";
            // 
            // btnSendTextbox
            // 
            btnSendTextbox.Enabled = false;
            btnSendTextbox.Location = new Point(46, 234);
            btnSendTextbox.Name = "btnSendTextbox";
            btnSendTextbox.Size = new Size(86, 40);
            btnSendTextbox.TabIndex = 3;
            btnSendTextbox.Text = "Send To UCI Engine";
            btnSendTextbox.UseVisualStyleBackColor = true;
            btnSendTextbox.Click += BtnSendTextbox_Click;
            // 
            // lbCommands
            // 
            lbCommands.FormattingEnabled = true;
            lbCommands.ItemHeight = 15;
            lbCommands.Location = new Point(572, 57);
            lbCommands.Name = "lbCommands";
            lbCommands.Size = new Size(216, 379);
            lbCommands.TabIndex = 5;
            lbCommands.SelectedIndexChanged += LbCommands_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 54);
            label3.Name = "label3";
            label3.Size = new Size(126, 15);
            label3.TabIndex = 14;
            label3.Text = "EnginePath\\Name.EXE";
            // 
            // tbPathToEngine
            // 
            tbPathToEngine.Location = new Point(46, 28);
            tbPathToEngine.Name = "tbPathToEngine";
            tbPathToEngine.Size = new Size(742, 23);
            tbPathToEngine.TabIndex = 13;
            tbPathToEngine.Text = "C:\\Engines\\MyUCIChessENg.exe";
            tbPathToEngine.DoubleClick += TbPathToEngine_DoubleClick;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            AcceptButton = btnSendTextbox;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(tbPathToEngine);
            Controls.Add(lbCommands);
            Controls.Add(btnSendTextbox);
            Controls.Add(tbCommand);
            Controls.Add(btnQuit);
            Controls.Add(btnSendCommand);
            Controls.Add(btnStartProcess);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnStartProcess;
        private Button btnSendCommand;
        private Button btnQuit;
        private TextBox tbCommand;
        private Button btnSendTextbox;
        private ListBox lbCommands;
        private ToolTip toolTip1;
        private Label label3;
        private TextBox tbPathToEngine;
        private OpenFileDialog openFileDialog1;
    }
}
