using System.Windows.Forms;

namespace ChessSpoon
{
    public partial class Form1 : Form
    {
        //declare the UCIEngine here so it persists for all controls on the form
        private ClassUCI UCIEngine = new ClassUCI();
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnStartProcess_Click(object sender, EventArgs e)
        {
            //ClassUCI UCIEngine = new ClassUCI();
            //"C:\\CHESS\\Engines\\Stockfish 17.0\\stockfish-windows-x86-64-avx2\\stockfish\\stockfish-windows-x86-64-avx2.exe"
            UCIEngine.StartEngine( this.tbPathToEngine.Text);
            this.btnStartProcess.Enabled = false;
            this.btnSendCommand.Enabled = true;
            this.btnSendTextbox.Enabled = true;
            this.btnQuit.Enabled = true;
        }



        private void BtnQuit_Click(object sender, EventArgs e)
        {
            UCIEngine.StopEngine();
            this.btnStartProcess.Enabled = true;
            this.btnSendCommand.Enabled = false;
            this.btnSendTextbox.Enabled = false;
            this.btnQuit.Enabled = false;
        }

        private void BtnSendCommand_Click(object sender, EventArgs e)
        {
            UCIEngine.SendCommand("uci");
            UCIEngine.SendCommand("isready");
        }

        private void BtnSendTextbox_Click(object sender, EventArgs e)
        {
            string sUCICommand = tbCommand.Text.Trim();
            tbCommand.Text = sUCICommand;
            UCIEngine.SendCommand(sUCICommand);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Common commands to engine
            lbCommands.Items.Add("uci");
            lbCommands.Items.Add("isready");
            lbCommands.Items.Add("ucinewgame");
            lbCommands.Items.Add("setoption name MultiPV value 3");
            lbCommands.Items.Add("position startpos");
            lbCommands.Items.Add("position startpos moves e2e4");
            lbCommands.Items.Add("d");
            lbCommands.Items.Add("position startpos moves e2e4 e7e5");
            lbCommands.Items.Add("go movetime 2000");
            lbCommands.Items.Add("stop");
            lbCommands.Items.Add("position fen r1bq1rk1/pp1nppbp/5np1/2pp4/3P1B2/4PN2/PPPNBPPP/2RQK2R w K c6 0 8");
            lbCommands.Items.Add("position fen r2r2k1/pp3p1p/3qn1p1/4R3/bPPp4/1N1Q2P1/P4PP1/2RB2K1 w - - 1 21");
            lbCommands.Items.Add("position fen rnbqkbnr/pppp1ppp/8/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 0 2");
            lbCommands.Items.Add("go");

        }

        private void LbCommands_SelectedIndexChanged(object sender, EventArgs e)
        {
            int iNdx = lbCommands.SelectedIndex;
            this.tbCommand.Text = lbCommands.Items[iNdx].ToString();
            //this.tbCommand.Text = lbCommands.Items(lbCommands.SelectedItems(iNdx)); 
        }

        private void TbPathToEngine_DoubleClick(object sender, EventArgs e)
        {
            this.openFileDialog1.Filter = "EXE Files (*.EXE)|*.EXE|All Files (*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.tbPathToEngine.Text = openFileDialog1.FileName;
            }
        }
    }
}
